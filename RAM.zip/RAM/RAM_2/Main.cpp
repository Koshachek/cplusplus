//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "Info.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;
int procent = 0;
void MemStatus(){
        MEMORYSTATUSEX ms;
        ms.dwLength = sizeof(MEMORYSTATUSEX);
        GlobalMemoryStatusEx(&ms);
        MainForm->ProgressBar->Max = (int)(ms.ullTotalPhys/1024/1000);
        MainForm->LabelInfo->Caption = AnsiString(ms.ullTotalPhys/1024/1000 - ms.ullAvailPhys/1024/1000) + "MB �� "
                        + AnsiString(ms.ullTotalPhys/1024/1000) + "MB";
        MainForm->ProgressBar->Position = (int)(ms.ullTotalPhys/1024/1000 - ms.ullAvailPhys/1024/1000);

        int total = (int)(ms.ullTotalPhys/1024/1000);
        int avail = (int)(ms.ullTotalPhys/1024/1000 - ms.ullAvailPhys/1024/1000);

        procent = (avail * 100)/total;
        MainForm->StatusBar->Panels->Items[1]->Text = procent;
}
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
        StatusBar->Panels->Items[0]->Text="��������� �������: %";        
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Timer1Timer(TObject *Sender)
{
         MemStatus();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::N2Click(TObject *Sender)
{
        AboutForm->ShowModal();
}
//---------------------------------------------------------------------------

